#include <iostream>

#include "player.h"
#include "blackjack.h"

using namespace std;


int main() {
    Player* p0 = new Player("p0");
    Player* dealer = new Player("Dealer");

    BlackJack game = BlackJack();
    game.addPlayer(p0);
    game.addPlayer(dealer);

    Player* winner;
    
    winner = game.playRound();

    if( winner == NULL )
        cout << "No winner this round." << endl;
    else {
        cout << winner->name() << " won with hand: ";
        winner->printPrivateHand();
    }
}
