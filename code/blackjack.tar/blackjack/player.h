#ifndef PLAYER_H
#define PLAYER_H

#include <vector>
#include <string>

#include "card.h"

class Player {
public:
    Player(const char* name) : pname(name), stay(false) {}

    /**
     * Add a card to player's hand
     *
     * \param Card* Card to add
     */
    void addCard(Card *a) { hand.push_back(a); }

    /**
     * Reset player's hand and status
     */
    void reset() { hand.clear(); stay = false; }

    void stayHand() { stay = true; }

    /**
     * Print hand keeping first 2 cards hidden
     *
     * Used for displaying all hands on the table
     */
    void printPublicHand();

    /**
     * Print hand
     *
     * Used for displaying the player's hand
     */
    void printPrivateHand();

    bool stayed() { return stay; }
    bool busted() { return privateTotal() > 21; }

    std::string name() { return pname; }

    /**
     * Calculate value of hand including hidden cards
     */
    int privateTotal();

private:
    std::string pname;
    std::vector<Card*> hand;
    bool stay;
};

#endif
