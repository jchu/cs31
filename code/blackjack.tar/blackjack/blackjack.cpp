/**********************************************************\
 *
 * BlackJack
 *
 * A single game of BlackJack
 *
 * Game Description:
 *
 * Players are initially dealt 2 cards. Each turn, a player
 * can choose to 'hit' to get another card or otherwise
 * 'stay'. A player's hand has a sum total of the rank of
 * cards except: All face cards have a value of 10 and the
 * Ace has either a value of 1 or 11.
 *
 * Players compete to get a higher value hand. However, the
 * maximum value is 21. A player goes 'bust' when their hand
 * is worth more than 21.
 *
 * Class Description:
 *
 * BlackJack can accept any number of players via addPlayer.
 * The first player added is assumed to be the User. All
 * other players are AI and follow the Naive AI Strategy
 * (hit when score is < 13, stay otherwise).
 *
 * playRound() plays a single round. When the deck is empty,
 * the game is over.
 *
\**********************************************************/

#include <vector>
#include <string>
#include <iostream>

#include "deck.h"
#include "player.h"
#include "blackjack.h"

using namespace std;

BlackJack::BlackJack() {
    deck = Deck();
    deck.shuffle();
}

/**
 * Play a single round of BlackJack
 *
 * \return Player* Winning player. Can be NULL
 */
Player* BlackJack::playRound() {
    dealInitial();

    if(deck.empty()) {
        cout << "Deck is empty. Game cannot be played. " << endl;
        return NULL;
    }

    // Overview of inital hands

    cout << "Your hand: ";
    players[0]->printPrivateHand();
    for(unsigned int i = 1; i < players.size(); i++) {
        cout << "Player " << i << "'s hand: ";
        players[i]->printPublicHand();
    }

    // Play turns
    while( !roundOver() )
        playTurn();

    cout << "Round over!" << endl << endl;

    return winner();
}

/**
 * Play a single turn for all players
 */
void BlackJack::playTurn() {
    char choice;
    Card *draw;

    // Go through each player
    for(unsigned int i = 0; i < players.size(); i++) {
        // No more cards!
        if(deck.empty())
            return;

        cout << players[i]->name() << "'s hand: ";


        // Show hands
        if( i == 0 )
            players[i]->printPrivateHand();
        else
            players[i]->printPublicHand();

        // Skip if no actions can be taken
        if( players[i]->stayed() || players[i]->busted() )
            continue;

        // Prompt user for choice or use AI for non-users
        if( i == 0 )
            choice = promptChoice(players[i]);
        else
            choice = naiveAIStrategy(players[i]);

        switch(choice) {
            case 'h':
                cout << "Hit me!" << endl;
                draw = deck.deal();
                cout << players[i]->name() << " drew a ";
                draw->print();
                cout << endl;
                players[i]->addCard(draw);
                break;
            case 's':
                cout << "I stay!" << endl;
                players[i]->stayHand();
                break;
        };

        if( players[i]->busted() ) {
            cout << players[i]->name() << " busted!" << endl;
        }
    }
}

/**
 * Deal the initial cards to all players
 *
 * Each player gets 2 cards
 */
void BlackJack::dealInitial() {
    for(unsigned int i = 0; i < players.size(); i++) {
        if(deck.empty())
            return;

        players[i]->addCard(deck.deal());
    }
    for(unsigned int i = 0; i < players.size(); i++) {
        if(deck.empty())
            return;

        players[i]->addCard(deck.deal());
    }
}

/**
 * Prompt player for actions
 *
 * \return char Action chosen
 */
char BlackJack::promptChoice(Player* player) {
    char choice;

    do {
        cout << player->name() << " available actions: (h)it, (s)tay: ";
        cin >> choice;
        cout << endl;

        switch(choice) {
            case 'h':
            case 's':
                return choice;
            default:
                cout << "Invalid choice" << endl;
        };
    } while(true);
}

/**
 * Determine if the round is over
 *
 * Round ends when there is a winner or everyone
 * loses or when the deck is empty.
 *
 * \return bool True when round is over
 */
bool BlackJack::roundOver() {
    int playing = players.size();

    // No more cards!
    if(deck.empty())
        return true;

    for(unsigned int i = 0; i < players.size(); i++) {
        if( players[i]->stayed() ) // stayed
            playing--;
        else if( players[i]->privateTotal() > 21 ) // busted
            playing--;
        else if( players[i]->privateTotal() == 21 ) // win
            return true;
    }

    // All payers either stayed or busted
    if( playing == 0 )
        return true;

    return false;
}

/**
 * Find the winner
 *
 * \return Player* Winning Player. Can be NULL
 */
Player* BlackJack::winner() {
    Player* winner = NULL;
    int bestScore = 0;
    for(unsigned int i = 0; i < players.size(); i++) {

        // Show final hand
        cout << players[i]->name() << " (" << players[i]->privateTotal() << "): ";
        players[i]->printPrivateHand();

        // Find best score so far
        if( !players[i]->busted() ) {
            if( players[i]->privateTotal() > bestScore ) {
                bestScore = players[i]->privateTotal();
                winner = players[i];
            }
        }
    }

    return winner;
}

/**
 * Naive strategy
 *
 * Hit when value is lower than 13. Stay otherwise.
 *
 * Used for non-user players.
 */
char BlackJack::naiveAIStrategy(Player *player) {
    if( player->privateTotal() < 13 )
        return 'h';
    return 's';
}
