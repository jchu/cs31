#ifndef DECK_H
#define DECK_H

#include "card.h"

const int DECK_SIZE = 52;
 
class Deck {
public:
    Deck();

    /** 
     * Shuffle deck
     *
     * Shuffle the entire deck
     */
    void shuffle();
    
    /**
     * Deal the topmost card
     *
     * Remove and return the topmost card
     *
     * \return Card* Card dealt. Can be NULl
     */
    Card *deal();
    bool empty() { return size == 0; }

    void print();

private:

    /** 
     * Shuffle deck
     *
     * \param size  size of deck left to shuffle
     */
    void shuffle(int shufflesize);

    /**
     * Swap any pair of cards in the deck
     *
     * \param posA     A card position
     * \param posB     Another card position
     */
    void swap_cards(int posA, int posB);

    Card *deck[DECK_SIZE]; // deck of Card pointers
    int size; // number of cards in deck
};

#endif
