#ifndef CARD_H
#define CARD_H

class Card {
public:
    Card(int new_rank, int new_suit);

    void print();

    // Overload type cast to integer
    operator int() {

        // Face values have value 10
        if( rank > 10 )
            return 10;

        return rank;
    }

private:
    int rank; // 1 - 13
    int suit; // H, S, D, C
};

#endif
