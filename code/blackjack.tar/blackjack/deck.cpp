#include <iostream>
#include <cstdlib>
#include <ctime>

#include "card.h"
#include "deck.h"

using namespace std;

/**
 * Initialize a completely ordered deck
 */
Deck::Deck() : size(DECK_SIZE) {
    for(int i = 0; i < size; i++) {
        int rank = (i % 13) + 1;
        int suit = i / 13;
        deck[i] = new Card(rank, suit);
    }
    srand(time(0));
}

/** 
 * Shuffle deck
 *
 * Shuffle the entire deck
 */
void Deck::shuffle() {
    if( size == 0 )
        return;
    int i = rand() % size;
    swap_cards(i, size - 1);
    shuffle(size - 1);
}

/**
 * Deal the topmost card
 *
 * Remove and return the topmost card
 *
 * \return Card* Card dealt. Can be NULL.
 */
Card* Deck::deal() {
    if( size - 1 < 0 )
        return NULL;

    Card* top = deck[size - 1];
    size--;
    return top;
}

/** 
 * Shuffle deck
 *
 * \param size  size of deck left to shuffle
 */
void Deck::shuffle(int shufflesize) {
    if( shufflesize != 0 ) {
        int i = rand() % shufflesize;
        swap_cards(i, shufflesize - 1);
        shuffle(shufflesize - 1);
    }
}
 
 
/**
 * Swap any pair of cards in the deck
 *
 * \param posA     A card position
 * \param posB     Another card position
 */
void Deck::swap_cards(int posA, int posB) {
    if( posA != posB ) {
        Card *temp = deck[posB];
        deck[posB] = deck[posA];
        deck[posA] = temp;
    }
}

/**
 * Print out cards in the deck
 */
void Deck::print() {
    for(int i = 0; i < size; i++ ) {
        if(i % 13 == 0)
            cout << endl;
        deck[i]->print();
        cout << "\t";
    }
    cout << endl;
}
