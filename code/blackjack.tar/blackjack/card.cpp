#include <iostream>

#include "card.h"

using namespace std;

/**
 * Constructor
 *
 * Initialize rank and suit
 */
Card::Card(int new_rank, int new_suit)
    : rank(new_rank), suit(new_suit) {}

/**
 * Print out a card
 */
void Card::print() {
    switch(rank) {
        case 1:
            cout << "A";
            break;
        case 11:
            cout << "J";
            break;
        case 12:
            cout << "Q";
            break;
        case 13:
            cout << "K";
            break;
        default:
            cout << rank;
            break;
    };
 
    switch(suit) {
        case 0:
            cout << "H";
            break;
        case 1:
            cout << "S";
            break;
        case 2:
            cout << "D";
            break;
        case 3:
            cout << "C";
            break;
    };
}
