#ifndef GAME_H
#define GAME_H

#include <vector>

#include "deck.h"
#include "player.h"

const int HIT = 0;
const int FOLD = 1;
const int STAY = 2;

const int TARGET = 21;

class BlackJack {

public:
    BlackJack();

    /**
     * Add a new player to the game
     *
     * \param Player* Player to add
     */
    void addPlayer(Player *p) { players.push_back(p); }

    /**
     * Play a single round of BlackJack
     *
     * \return Player* Winning player. Can be NULL
     */
    Player* playRound();

    /**
     * Play a single turn for all players
     */
    void playTurn();

private:

    /**
     * Deal the initial cards to all players
     */
    void dealInitial();

    /**
     * Prompt player for actions
     *
     * \return char Action chosen
     */
    char promptChoice(Player *player);

    /**
     * Determine if the round is over
     *
     * Round ends when there is a winner or everyone
     * loses.
     *
     * \return bool True when round is over
     */
    bool roundOver();

    /**
     * Find the winner
     *
     * \return Player* Winning Player. Can be NULL
     */
    Player* winner();

    /**
     * Naive strategy
     *
     * Hit when value is lower than 13. Stay otherwise.
     *
     * Used for non-user players.
     */
    char naiveAIStrategy(Player *player);

    std::vector<Player *> players; // List of players
    Deck deck; 
};

#endif
