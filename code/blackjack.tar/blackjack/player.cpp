#include <iostream>

#include "card.h"
#include "player.h"

using namespace std;

void Player::printPublicHand() {
    cout << "XX XX ";
    for(unsigned int i = 2; i < hand.size(); i++ ) {
        hand[i]->print();
        cout << " ";
    }
    cout << endl;
}

void Player::printPrivateHand() {
    for(unsigned int i = 0; i < hand.size(); i++ ) {
        hand[i]->print();
        cout << " ";
    }
    cout << endl;
}

/**
 * Calculate value of hand including hidden cards
 */
int Player::privateTotal() {
    if( hand.size() < 2 )
        return -1;

    int sum = 0;
    int numAces = 0;
    for(unsigned int i = 0; i < hand.size(); i++ ) {
        if( *hand[i] == 1 )
            numAces++;
        else
            sum += *hand[i];
    }
    
    int tempSum;
    for(int j = numAces; j >= 0; j--) {
        tempSum = sum + (j * 11) + (numAces - j);
        if(tempSum <= 21)
            return tempSum;
    }
    return sum;
}
