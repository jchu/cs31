#include "paddle.h"

/**
 * Move the paddle in a direction
 *
 * \param char dir      character representing direction
 * \param double xmax   max x position for paddle
 */
void Paddle::move(char dir, double xmax) {
    switch(dir) {
        case 'l': // move left
            px -= 1;
            break;
        case 'r': // move right
            px += 1;
            break;
    };

    if( px < 1 ) // stop if hit left wall
        px = 1;
    else if( px + pwidth >= xmax ) // stop if hit right wall
        px = xmax - pwidth;
}
