#ifndef PADDLE_H
#define PADDLE_H

class Paddle {

public:
    Paddle(double initx, double inity, double initwidth)
        : px(initx), py(inity), pwidth(initwidth) {}

    // Accessors
    double left() const { return px; }
    double right() const { return px+pwidth; }
    double width() const { return pwidth; }
    double y() const { return py; }

    /**
     * Move the paddle in a direction
     *
     * \param char dir      character representing direction
     * \param double xmax   max x position for paddle
     */
    void move(char dir, double xmax);

private:
    double px, py;
    double pwidth;
};

#endif
