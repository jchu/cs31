#include "ball.h"

/**
 * Move the ball and consider bounces and endgame
 *
 * Ball normally moves bxvel, byvel in one tick.
 * May hit walls or paddle and reverse direction.
 * Stops moving once it hits the floor.
 *
 * \param xmax          max x position for ball
 * \param ymax          max y position for ball
 * \param paddleleft    left x position of paddle
 * \param paddleright   right x position of paddle
 * \param paddley       y position of paddle
 */
void Ball::move(double xmax, double ymax, double paddleleft, double paddleright, double paddley) {
    if( x + bxvel < 0 ) {   // hit left wall
        x = -(x + bxvel);
        bxvel = -bxvel;
    } else if( x + bxvel >= xmax ) { // hit right wall
        x = (2 * xmax) - (x + bxvel);
        bxvel = -bxvel;
    } else { // normal
        x += bxvel;
    }

    if( y + byvel > ymax ) { // hit ceiling
        y = (2 * ymax) - (y + byvel);
        byvel = -byvel;
    } else if( y + byvel < paddley
        && (x > paddleleft && x < paddleright)) { // hit paddle
        y = (2 * paddley) - (y + byvel);
        byvel = -byvel;
    } else if( y + byvel < 0 ) { // hit floor, ENDGAME
        bxvel = 0;
        byvel = 0;
        x = -1;
        y = -1;
    } else { // normal
        y += byvel;
    }
}
