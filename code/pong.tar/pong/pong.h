#ifndef PONG_H
#define PONG_H

#include "ball.h"
#include "paddle.h"

// Game constants
const double GAME_WIDTH =       41;
const double GAME_HEIGHT =      40;
const double PADDLE_X =         6;
const double PADDLE_Y =         5;
const double PADDLE_WIDTH =     10;
const double BALL_INITX =       21;
const double BALL_INITY =       30;
const double BALL_INITXVEL =    -2;
const double BALL_INITYVEL =    -2;

class Pong {

public:
    Pong() : gwidth(GAME_WIDTH), gheight(GAME_HEIGHT),
        ball(BALL_INITX, BALL_INITY, BALL_INITXVEL, BALL_INITYVEL),
        paddle(PADDLE_X, PADDLE_Y, PADDLE_WIDTH) {};

    // Accessors
    double width() { return gwidth; }
    double height() { return gheight; }

    /**
     * Execute a single tick of the game
     *
     * Display board, ask for user input, and move paddle/board
     *
     * \return bool false on game over
     */
    bool tick();

    /**
     * Display the board, ball, paddle
     */
    void display();

private:
    double gwidth, gheight;
    Ball ball;
    Paddle paddle;
};

#endif
