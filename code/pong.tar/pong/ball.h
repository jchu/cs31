#ifndef BALL_H
#define BALL_H

class Ball {

public:

    Ball(double initx, double inity, double initxvel, double inityvel)
        : x(initx), y(inity), bxvel(initxvel), byvel(inityvel) {}

    // Accessors
    double xpos() const { return x; }
    double ypos() const { return y; }
    double xvel() const { return bxvel; }
    double yvel() const { return byvel; }

    /**
     * Move the ball and consider bounces and endgame
     *
     * \param xmax          max x position for ball
     * \param ymax          max y position for ball
     * \param paddleleft    left x position of paddle
     * \param paddleright   right x position of paddle
     * \param paddley       y position of paddle
     */
    void move(double xmax, double ymax, double paddleleft, double paddleright, double paddley);

private:
    double x, y;
    double bxvel, byvel;
};

#endif
