#include <iostream>

#include "pong.h"

using namespace std;

int main() {
    cout << "Pong" << endl;

    Pong game = Pong();

    while(true) {
        // Run the game for one tick
        if( !game.tick() )
            break; // game is over when tick returns false
    }

    cout << "Game Over!" << endl;
}
