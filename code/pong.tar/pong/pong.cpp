#include <iostream>

#include "ball.h"
#include "paddle.h"
#include "pong.h"

using namespace std;

/**
 * Execute a single tick of the game
 *
 * Display board, ask for user input, and move paddle/board
 *
 * \return bool false on game over
 */
bool Pong::tick() {
    display();

    char dir;
    cout << "Move paddle (l, r, n): ";
    cin >> dir;

    paddle.move(dir, gwidth-1);
    ball.move(gwidth-1, gheight-1, paddle.left(), paddle.right(), paddle.y());

    if( ball.ypos() < 0 )
        return false;
    return true;
}

/**
 * Display the board, ball, paddle
 *
 * Board runs from 0 to gwidth and 0 to gheight.
 * (0,0) is bottem left corner
 * Board has a 1 character border on the edges
 */
void Pong::display() {
    for( int y = gheight; y >= 0; y-- ) {
        for( int x = 0; x <= gwidth; x++ ) {
            if( y == gheight || y == 0 ) {
                if( x == 0 || x == gwidth )
                    cout << '+'; // corners
                else
                    cout << '-'; // top/bottom edges
            } else if(x == 0 || x == gwidth) {
                cout << "|"; // side edges
            } else if( ball.xpos() == x && ball.ypos() == y ) {
                cout << 'o'; // ball position
            } else if( paddle.y() == y
                    && (paddle.left() <= x && paddle.right() >= x)) {
                cout << '_'; // paddle
            } else {
                cout << ' '; // empty space
            }

            if( x == gwidth ) {
                cout << endl; // newline for next row
            }
        }
    }
}
